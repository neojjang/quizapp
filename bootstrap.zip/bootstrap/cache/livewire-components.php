<?php return array (
  'incorrect-answer-note' => 'App\\Http\\Livewire\\IncorrectAnswerNote',
  'make-answer-sheet-form' => 'App\\Http\\Livewire\\MakeAnswerSheetForm',
  'make-test-answer-form' => 'App\\Http\\Livewire\\MakeTestAnswerForm',
  'user-answer' => 'App\\Http\\Livewire\\UserAnswer',
  'user-datatable' => 'App\\Http\\Livewire\\UserDatatable',
  'user-quizlv' => 'App\\Http\\Livewire\\UserQuizlv',
);